//
//  Plant.swift
//  MyGarden2
//
//  Created by Reema Alhabdan on 10/01/2023.
//

import Foundation



struct Plant: Identifiable{
    let id = UUID().uuidString
    let name: String
    
}
