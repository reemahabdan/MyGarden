//
//  LottieFile.swift
//  MyGarden2
//
//  Created by Reema Alhabdan on 10/01/2023.
//

import SwiftUI

struct LottieFile: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LottieFile_Previews: PreviewProvider {
    static var previews: some View {
        LottieFile()
    }
}
