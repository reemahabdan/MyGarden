//
//  File.swift
//  MyGarden2
//
//  Created by Reema Alhabdan on 10/01/2023.
//

import Foundation


@MainActor class viewModel: ObservableObject{
    @Published var showingSheet = false

}
