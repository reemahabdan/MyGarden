//
//  ViewModel.swift
//  MyGarden2
//
//  Created by Reema Alhabdan on 10/01/2023.
//

//import Foundation
//
//
//
//final class ViewModel: ObservableObject{
//    @Published var plants : [Plant] = []
//    init(){
//        fetchPlants()
//    }
//    func fetchPlants(){
//        plants.append(Plant(name: "rose"))
//        // .. . . . in plants
//    }
//}
